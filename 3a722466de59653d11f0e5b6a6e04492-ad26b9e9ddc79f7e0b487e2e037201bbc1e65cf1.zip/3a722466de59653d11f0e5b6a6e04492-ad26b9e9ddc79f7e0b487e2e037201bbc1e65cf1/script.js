<!-----This is JS----> 

function mykey() {
  alert("Order has been placed.THANK YOU");
}

function changes() {
  let change = (document.getElementById("aad").style.color = "gold");
}
